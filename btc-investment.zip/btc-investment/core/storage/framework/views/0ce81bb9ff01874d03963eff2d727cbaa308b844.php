<?php $__env->startSection('content'); ?>


        <div class="row">
            <div class="col-md-12">


                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                        </div>
                        <div class="tools"> </div>
                    </div>
                    <div class="portlet-body">
                        <table class="table table-striped table-bordered table-hover" id="sample_1">

                            <thead>
                            <tr>
                                <th>ID#</th>
                                <th>Date</th>
                                <th>Ticket Number</th>
                                <th>Subject</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $i=0;?>
                            <?php $__currentLoopData = $support; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++;?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d F Y h:i A')); ?></td>
                                    <td><?php echo e($p->ticket_number); ?></td>
                                    <td><?php echo e($p->subject); ?></td>
                                    <td>
                                        <?php if($p->status == 1): ?>
                                            <span class="label label-info bold uppercase"> Opened</span>
                                        <?php elseif($p->status == 2): ?>
                                            <span class="label label-success bold uppercase"> Answered</span>
                                        <?php elseif($p->status == 3): ?>
                                            <span class="label bg-purple bold uppercase bg-font-purple"> Customer Reply</span>
                                        <?php elseif($p->status == 9): ?>
                                            <span class="label label-danger bold uppercase"> Closed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin-support-mess',$p->ticket_number)); ?>" class="btn btn-primary bold uppercase"><i class="fa fa-eye"></i> View</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div><!-- ROW-->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>