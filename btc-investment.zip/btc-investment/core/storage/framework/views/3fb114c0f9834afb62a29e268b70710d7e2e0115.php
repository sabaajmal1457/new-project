<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">

            <div class="portlet box blue">
                <div class="portlet-title">
                    <div class="caption uppercase">
                        <strong><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></strong>
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                    </div>
                </div>
                <div class="portlet-body" style="overflow: hidden">

                    <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-sm-3 text-center">
                            <div class="panel panel-primary panel-pricing">
                                <div class="panel-heading">
                                    <h3 style="font-size: 28px;"><b><?php echo e($p->name); ?></b></h3>
                                </div>
                                <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                                    <p><strong><?php echo e($p->minimum); ?> <?php echo e($basic->currency); ?> - <?php echo e($p->maximum); ?> <?php echo e($basic->currency); ?></strong></p>
                                </div>
                                <ul style='font-size: 15px;' class="list-group text-center bold">
                                    <li class="list-group-item"><i class="fa fa-check"></i> Commission - <?php echo e($p->percent); ?> <i class="fa fa-percent"></i> </li>
                                    <li class="list-group-item"><i class="fa fa-check"></i> Repeat - <?php echo e($p->time); ?> times </li>
                                    <li class="list-group-item"><i class="fa fa-check"></i> Compound - <span class="aaaa"><?php echo e($p->compound->name); ?></span></li>
                                    <li class="list-group-item"><span class="aaaa"><?php echo e($p->status == 1 ? "Active" : 'DeActive'); ?></span></li>
                                </ul>
                                <div class="panel-footer" style="overflow: hidden">
                                    <div class="col-sm-12">
                                        <a class="btn btn-block btn-primary bold uppercase" href="<?php echo e(route('plan-edit',$p->id)); ?>"><i class="fa fa-edit"></i> Edit plan</a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div><!---ROW-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>