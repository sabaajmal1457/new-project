<?php $__env->startSection('content'); ?>


        <div class="row">
            <div class="col-md-12">


                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-dark">
                            <a href="<?php echo e(route('support-open')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Open New Support Ticket</a>
                        </div>
                        <div class="tools"> </div>
                    </div>
                    <div class="portlet-body">
                        <table class="table table-striped table-bordered table-hover" id="sample_1">

                            <thead>
                            <tr>
                                <th>ID#</th>
                                <th>Date</th>
                                <th>Ticket Number</th>
                                <th>Subject</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $i=0;?>
                            <?php $__currentLoopData = $support; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++;?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d F Y h:i A')); ?></td>
                                    <td><?php echo e($p->ticket_number); ?></td>
                                    <td><?php echo e($p->subject); ?></td>
                                    <td>
                                        <?php if($p->status == 1): ?>
                                            <span class="label bold label-info"><i class="fa fa-eye"></i> Open</span>
                                        <?php elseif($p->status == 2): ?>
                                            <span class="label bold label-success"><i class="fa fa-check"></i> Answer</span>
                                        <?php elseif($p->status == 3): ?>
                                            <span class="label bold bg-purple bg-font-purple"><i class="fa fa-mail-reply"></i> Customer Reply</span>
                                        <?php elseif($p->status == 9): ?>
                                            <span class="label bold label-danger"><i class="fa fa-times"></i> Close</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('support-message',$p->ticket_number)); ?>" class="btn btn-primary"><i class="fa fa-eye"></i> View</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div><!-- ROW-->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>


    <?php if(session('success')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Success!", "<?php echo e(session('success')); ?>", "success");

            });

        </script>

    <?php endif; ?>



    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");

            });

        </script>

    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>